local KnightTransformData = class("KnightTransformData")

function KnightTransformData:ctor()
	
end

return KnightTransformData