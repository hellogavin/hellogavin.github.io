local HeroSoulBagData = class("HeroSoulBagData")

function HeroSoulBagData:ctor()

end

return HeroSoulBagData