local Cache = {}

local checkedDir = false

function Cache.getRolePrefix()
    return G_PlatformProxy:getLoginServer().id .. "_" .. G_Me.userData.id 
end

function Cache.path(filename)
    --todo, make subdir
    return Cache.writeDir() .. "/" .. filename
end

function Cache.rolePath(filename)
    --todo, make subdir
    return Cache.writeDir() .. "/" .. Cache.getRolePrefix() .. "_" .. filename
end

function Cache.writeDir() 
    local dir =  CCFileUtils:sharedFileUtils():getWritablePath() ..  "/userdata/"
    if not checkedDir then
        if not io.exists(dir) then
            --print("create dir..." .. dir)
            FuncHelperUtil:createDirectory(dir)

        end
        checkedDir = true
    end 


    return dir
end

function Cache.save(filename, data)
    io.writefile( filename, json.encode(data), "w+b" )
end



function Cache.load(filename)
    local str = io.readfile(filename, "rb")
    if str ~= nil then
        return json.decode(str)
    end
    return nil
end



return Cache
