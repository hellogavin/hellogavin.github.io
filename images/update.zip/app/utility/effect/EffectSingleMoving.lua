local EffectSingleMoving = class("EffectSingleMoving")

--ignoreAttr默认为空, 可以传哪些属性不做moving, 比如 position, opacity, scale, rotation
function EffectSingleMoving.run(node, effectJsonName, eventHandler, ignoreAttr, startFrame)
    local singleMoving = EffectSingleMoving.new(node, effectJsonName, eventHandler, ignoreAttr, startFrame)
    return singleMoving
end

return EffectSingleMoving