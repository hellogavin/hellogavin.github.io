protobuf = require("SM.pbc.protobuf")

G_EventMsg = require("app.network.EventMsg")
--后面这个可能要读取配置的
G_PlatformProxy =require(PROXY_CLASS).new() -- require("app.sdk.ComSdkProxy")

--用于自定义事件的监听和派发
G_Event = cc.Registry.classes_["components.behavior.EventProtocol"].new()

--游戏自定义事件名


--服务器列表
G_ServerList = require("app.scenes.login.ServerList").new()

G_lang = require("app.lang.Lang")

Colors = require("app.utility.Colors")

G_Setting = require("app.utility.Setting")

G_MovingTip = require("app.utility.ui.MovingTips").new()

G_Path = require("app.utility.Path")

G_flyAttribute = require("app.scenes.common.FlyAttributes")

G_NetMsg_ID = require("app.network.NetMsgID")

G_NetworkManager = require("app.network.NetworkManager").new()

G_HandlersManager = require("app.network.HandlersManager").new()

G_Me = require("app.data.Me").new()

G_NetMsgError = require("app.network.NetMsgError")

G_ServerTime = require("app.data.ServerTime").new()

G_GameService = require("app.scenes.common.GameService").new()

MessageBoxEx = require("app.scenes.common.MessageBoxEx")

G_RoleService = require("app.scenes.common.RoleService").new()

G_GlobalFunc = require("app.global.GlobalFunc")

G_SceneObserver = require("app.scenes.common.SceneObserver").new()

G_Job = require("app.utility.Job").new()

G_moduleUnlock = require("app.scenes.common.ModuleUnlock").new()

G_Goods = require("app.utility.Goods")

G_commonLayerModel = require("app.scenes.common.CommonLayerModel").new()

G_TopBarConst = require("app.const.TopBarConst")

G_SoundManager = require("app.sound.SoundManager")

G_WP8 = require("app.utility.Wp8Addition")