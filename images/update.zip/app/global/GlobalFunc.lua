GlobalFunc = {}


function GlobalFunc.sz_T2S(_t)
    local szRet = "{"
    function doT2S(_i, _v)
        if "number" == type(_i) then
            szRet = szRet .. "[" .. _i .. "] = "
            if "number" == type(_v) then
                szRet = szRet .. _v .. ","
            elseif "string" == type(_v) then
                szRet = szRet .. '"' .. _v .. '"' .. ","
            elseif "table" == type(_v) then
                szRet = szRet .. sz_T2S(_v) .. ","
            else
                szRet = szRet .. "nil,"
            end
        elseif "string" == type(_i) then
            szRet = szRet .. '["' .. _i .. '"] = '
            if "number" == type(_v) then
                szRet = szRet .. _v .. ","
            elseif "string" == type(_v) then
                szRet = szRet .. '"' .. _v .. '"' .. ","
            elseif "table" == type(_v) then
                --szRet = szRet .. sz_T2S(_v) .. ","
            else
                szRet = szRet .. "nil,"
            end
        end
    end
    table.foreach(_t, doT2S)
    szRet = szRet .. "}"
    return szRet
end

function GlobalFunc.createGameRichtext( txt, size, color, strokeColor )
    local winSize = CCDirector:sharedDirector():getWinSize()
    local richtext = CCSRichText:create(winSize.width, winSize.height/10)
    richtext:setFontSize(size or 20)
    richtext:setFontName("ui/font/FZYiHei-M20S.ttf")
    richtext:setColor(color or ccc3(255, 255, 255))
    if strokeColor ~= nil then
        richtext:enableStroke(strokeColor)
    end
    richtext:setShowTextFromTop(true)
    richtext:appendContent(txt or "", color or ccc3(255, 255, 255))
    richtext:reloadData()
    richtext:adapterContent()
   
   return richtext
end

function GlobalFunc.getDungeonData(id)
    --可配置活动去读dungeon_info_holiday
    --圣诞活动去读dungeon_info_holiday
    
    -- 多语言版本，只需要翻译一张dungeon_info表就可以了
    local func = function(id)
        if G_Me.activityData.custom:isDungeonActive() then
            import("dungeon_info_config")
            return dungeon_info_config.get(id)
        else
            if G_Me.activityData.holiday:isActivate() then
                import("dungeon_info_holiday")
                return dungeon_info_holiday.get(id)
            else
                import("dungeon_info")
                return dungeon_info.get(id)
            end
        end
    end

    import("dungeon_info")
    local tTmpl = func(id)
    local tNormalTmpl = dungeon_info.get(id)
    if tTmpl and tNormalTmpl then
        tTmpl.talk = tNormalTmpl.talk
    end

    return tTmpl
end

function GlobalFunc.sceneToPack( sceneName, params )
    return {name = sceneName, param = params}
end

function GlobalFunc.addTimer(interval, callback)
    local scheduler = require "framework.scheduler"
    return scheduler.scheduleGlobal(callback,interval)
end

function GlobalFunc.removeTimer(timerHandler)
    local scheduler = require "framework.scheduler"
    scheduler.unscheduleGlobal(timerHandler)
end

function GlobalFunc.trace(str)
   print(str) 
end

local _doFly1 = function ( ctrl, offset, vertical, delay, addition, func )
    if not ctrl then
        return 
    end

    if delay <= 0 then 
        if func then 
            func()
        end
    end

    addition = addition or 30
    if offset < 0 then 
        addition = -addition
    end
    local ease1 = CCEaseIn:create(CCMoveBy:create(delay, ccp(vertical and 0 or (offset + addition), vertical and (offset + addition) or 0)), delay)
    local ease2 = CCEaseIn:create(CCMoveBy:create(0.1, ccp(vertical and 0 or -addition, vertical and -addition or 0)), 0.1)
    local arr = CCArray:create()
    arr:addObject(ease1)
    arr:addObject(ease2)
    if func then 
        arr:addObject(CCCallFunc:create(function (  )
            func()
        end))
    end     
    ctrl:runAction(CCSequence:create(arr))   
end


function GlobalFunc.flyIntoScreenLR( ctrls, isLeft, delay, scale, addition, func )
    if not ctrls or type(ctrls) ~= "table" then
        return false
    end

    if delay < 0 then 
        return false
    end

    scale = scale or 1
    if scale < 0 then 
        scale = -scale
    end
    
    local size = CCDirector:sharedDirector():getWinSize()
    for key, value in pairs(ctrls) do 
        local posx, posy = value:convertToWorldSpaceXY(0, 0)
        local oldPosx, oldPosy = value:getPosition()
        local ctrlSize = value:getSize()
        local startPosx = isLeft and (-ctrlSize.width) or (size.width + ctrlSize.width)       
        if isLeft then 
            value:setPosition(ccp(oldPosx - scale*(posx - startPosx), oldPosy))
            _doFly1(value, scale*(posx - startPosx), false, delay + 0.1*(key - 1), addition, (key == #ctrls) and func or nil)
        else
            value:setPosition(ccp(oldPosx + scale*(startPosx - posx), oldPosy))
            _doFly1(value, - scale*(startPosx - posx), false, delay + 0.1*(key - 1), addition, (key == #ctrls) and func or nil)
        end        
    end
end

function GlobalFunc.showDayEffect( scenePart, parent )
    if not parent then 
        return 
    end

    local EffectNode = require "app.utility.effect.EffectNode"
    local isDaily = GlobalFunc.isNowDaily()
    
    local effects = {}
    if isDaily then 
        effects = G_Path.getDayEffect(scenePart)
    else
        effects = G_Path.getNightEffect(scenePart)
    end

    local isWidget = (parent.getWidgetType ~= nil)

    for key, value in pairs(effects) do 
        local effect  = nil 
        if value ~= "effect_zjmbt" then
            effect = EffectNode.new(value)
        else
            effect = EffectNode.new(value, function(event, frameIndex)
                if event and event == "hit" then 
                    G_SoundManager:playSound("audio/kxdh3.mp3")
                end
             end)
        end
        if effect then 
            effect:play()
            if isWidget then 
                parent:addNode(effect)
            else
                parent:addChild(effect)
            end
        end
    end
end

function GlobalFunc.replaceForAppVersion( image )
    if not image or not image.loadTexture then 
        return false
    end

    local appstoreVersion = (G_Setting:get("appstore_version") == "1")
    if appstoreVersion then 
        image:loadTexture("ui/arena/xiaozhushou_hexie.png", UI_TEX_TYPE_LOCAL)
    end

    return appstoreVersion
end

function GlobalFunc.createGameLabel( txt, size, color, strokeColor, labelSize, fixWidth )
   local label = Label:create()
   if labelSize then 
    label:setTextAreaSize(labelSize)
   end
   if fixWidth then 
    label:setFixedWidth(true)
   end
   label:setFontSize(size or 20)
   label:setFontName("ui/font/FZYiHei-M20S.ttf")
   label:setColor(color or ccc3(255, 255, 255))
   if strokeColor ~= nil then
        label:createStroke(strokeColor, 1)
   end
   label:setText(txt or "")
   
   return label
end

function GlobalFunc.table_is_empty(t)
    return _G.next( t ) == nil
end

function GlobalFunc.ConvertNumToCharacter(num)
    -- 过亿了
    if num >= math.pow(10,8) then
        return (num-num%math.pow(10,4))/math.pow(10,4) .. G_lang:get("LANG_WAN")
    end
    if num >= math.pow(10,6) then
        return (num-num%math.pow(10,4))/math.pow(10,4) .. G_lang:get("LANG_WAN")
    end
    return num
end

function GlobalFunc.isNowDaily( ... )
    local hour = 0
    if not G_ServerTime then 
        local time = os.time()
        local tab = G_ServerTime:getDateObject(time)
        --local tab = os.date("*t", time)
        hour = tab and tab.hour or 10
    else
        hour = G_ServerTime:getCurrentHHMMSS()
    end

    if G_Me and G_Me.userData and type(G_Me.userData.level) == "number" and G_Me.userData.level < 20 then 
        return true
    end

    return (hour >= 6 and hour < 18)
end

function GlobalFunc.sayAction(widget,hide,callback,move,hideTime,scale)
    hide = hide or false
    move = move or false
    hideTime = hideTime or 2.1
    scale = scale or 1
    local baseScale = CCScaleTo:create(0.5,scale)
    local animeDelay = CCDelayTime:create(hideTime)
    widget:setScale(0.1)
    widget:setVisible(true)
    if move then
        local basePos = ccp(widget:getPosition())
        local rect = widget:getContentSize()
        local dstPos = ccp(basePos.x,basePos.y+rect.height/2)
        local animeMove = CCMoveTo:create(0.5,basePos)
        widget:setPosition(dstPos)
        baseScale = CCSpawn:createWithTwoActions(baseScale, animeMove)
    end
    local animeScale = CCEaseBounceOut:create(baseScale)
    if not hide then
        widget:runAction(animeScale)
    else
        local arr = CCArray:create()
        arr:addObject(animeScale)
        arr:addObject(animeDelay)
        arr:addObject(CCCallFunc:create(function()
                    widget:setVisible(false)
                    if callback then
                        callback()
                    end
            end))
        local anime = CCSequence:create(arr)
        widget:runAction(anime)
    end
end

function GlobalFunc.formatText( mainText, values )
    if not mainText or type(values) ~= "table" then 
        return ""
    end

    local tempText = mainText
    for k,v in pairs(values) do
        tempText = string.gsub(tempText, "#" .. k .. "#", v)            
    end

    return tempText
end

return GlobalFunc