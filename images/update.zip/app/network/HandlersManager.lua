--HandlersManager.lua



local HandlersManager = class ("HandlersManager")

function HandlersManager:ctor( ... )
    self._monitorProtocals = {}
    self._handlers = {}
    self:_initHandlers(...)
end

function HandlersManager:_createHandler(handlerClass, handlerName)
    local handler = require(handlerClass).new()
    handler:initHandler()
    self._handlers[handlerName] = handler
    return handler
end

function HandlersManager:_initHandlers( ... )
    self.coreHandler = self:_createHandler("app.network.handler.CoreHandler", "coreHandler")
    self.codeHandler = self:_createHandler("app.network.handler.CodeHandler", "CodeHandler")
    self.chatHandler = self:_createHandler("app.network.handler.ChatHandler", "chatHandler")
    self.fightResourcesHandler = self:_createHandler("app.network.handler.FightResourcesHandler", "fightResourcesHandler")
    self.shopHandler = self:_createHandler("app.network.handler.ShopHandler", "shopHandler")
    self.storyDungeonHandler = self:_createHandler("app.network.handler.StoryDungeonHandler", "storyDungeonHandler")
    self.activityHandler = self:_createHandler("app.network.handler.ActivityHandler", "activityHandler")  
    self.cardHandler = self:_createHandler("app.network.handler.CardHandler", "cardHandler")
    self.titleHandler = self:_createHandler("app.network.handler.TitleHandler", "TitleHandler")
    self.bagHandler = self:_createHandler("app.network.handler.BagHandler", "bagHandler")
--[[    self.chatHandler = self:_createHandler("app.network.handler.ChatHandler", "chatHandler")
    
    self.arenaHandler = self:_createHandler("app.network.handler.ArenaHandler", "arenaHandler")
    
    self.friendHandler = self:_createHandler("app.network.handler.FriendHandler", "friendHandler")
    self.fundHandler = self:_createHandler("app.network.handler.FundHandler", "fundHandler")
    self.battleHandler = self:_createHandler("app.network.handler.BattleHandler", "battleHandler")
    self.monthFundHandler = self:_createHandler("app.network.handler.MonthFundHandler", "monthFundHandler")

    self.dungeonHandler = self:_createHandler("app.network.handler.DungeonHandler", "dungeonHandler")
    self.hardDungeonHandler = self:_createHandler("app.network.handler.HardDungeonHandler", "hardDungeonHandler")
--    self.timeDungeonHandler = self:_createHandler("app.network.handler.TimeDungeonHandler", "timeDungeonHandler")
    self.timePrivilegeHandler = self:_createHandler("app.network.handler.TimePrivilegeHandler", "timePrivilegeHandler")

    self.towerHandler = self:_createHandler("app.network.handler.TowerHandler", "towerHandler")
    self.wushHandler = self:_createHandler("app.network.handler.WushHandler", "wushHandler")
    
    self.mailHandler = self:_createHandler("app.network.handler.MailHandler", "mailHandler")
    
    self.heroUpgradeHandler = self:_createHandler("app.network.handler.HeroUpgradeHandler", "heroUpgradeHandler")
    self.equipmentStrengthenHandler = self:_createHandler("app.network.handler.EquipmentStrengthenHandler", "equipmentStrengthenHandler")
    self.giftMailHandler = self:_createHandler("app.network.handler.GiftMailHandler", "giftMailHandler")
    self.secretShopHandler = self:_createHandler("app.network.handler.SecretShopHandler", "secretShopHandler")

    

    self.moshenHandler = self:_createHandler("app.network.handler.MoShenHandler", "moShenHandler")
    self.handBookHandler = self:_createHandler("app.network.handler.HandBookHandler", "handBookHandler")
    self.treasureRobHandler = self:_createHandler("app.network.handler.TreasureRobHandler", "treasureRobHandler")
    
    self.treasureHandler = self:_createHandler("app.network.handler.TreasureHandler", "treasureHandler")
    self.recycleHandler = self:_createHandler("app.network.handler.RecycleHandler", "recycleHandler")
    self.guideHandler = self:_createHandler("app.network.handler.GuideHandler", "guideHandler")
    self.noticeHandler = self:_createHandler("app.network.handler.NoticeHandler", "noticeHandler")
    self.vipHandler = self:_createHandler("app.network.handler.VipHandler", "vipHandler")
    self.dailytaskHandler = self:_createHandler("app.network.handler.DailytaskHandler", "dailytaskHandler")
    
    self.targetHandler = self:_createHandler("app.network.handler.TargetHandler", "targetHandler")
    --三国志handler
    self.sanguozhiHandler = self:_createHandler("app.network.handler.SanguozhiHandler","sanguozhiHandler")
    self.hallOfFrameHandler = self:_createHandler("app.network.handler.HallOfFrameHandler", "hallofframeHandler")

    self.daysActivityHandler = self:_createHandler("app.network.handler.DaysActivityHandler", "daysActivityHandler")
    
    self.cityHandler = self:_createHandler("app.network.handler.CityHandler", "CityHandler")
    self.dressHandler = self:_createHandler("app.network.handler.DressHandler", "DressHandler")
    self.legionHandler = self:_createHandler("app.network.handler.LegionHandler", "LegionHandler")

    self.gmActivityHandler = self:_createHandler("app.network.handler.GMActivityHandler", "GMActivityHandler")
    
    self.rookieBuffHandler = self:_createHandler("app.network.handler.RookieBuffHandler", "RookieBuffHandler")
    self.avatarFrameHandler = self:_createHandler("app.network.handler.AvatarFrameHandler", "AvatarFrameHandler")
    self.crusadeHandler = self:_createHandler("app.network.handler.CrusadeHandler", "CrusadeHandler")
    
    self.shareHandler = self:_createHandler("app.network.handler.ShareHandler", "ShareHandler")
    self.wheelHandler = self:_createHandler("app.network.handler.WheelHandler", "WheelHandler")
    self.richHandler = self:_createHandler("app.network.handler.RichHandler", "RichHandler")
    
    self.awakenShopHandler = self:_createHandler("app.network.handler.AwakenShopHandler", "AwakenShopHandler")
    self.crossWarHandler = self:_createHandler("app.network.handler.CrossWarHandler", "CrossWarHandler")
    

    

    self.knightTransformHandler = self:_createHandler("app.network.handler.KnightTransformHandler", "knightTransformHandler")

    self.themeDropHandler = self:_createHandler("app.network.handler.ThemeDropHandler", "themeDropHandler")

    self.groupBuyHandler = self:_createHandler("app.network.handler.GroupBuyHandler", "groupBuyHandler")
    self.petHandler = self:_createHandler("app.network.handler.PetHandler", "PetHandler")
    self.dailyPvpHandler = self:_createHandler("app.network.handler.DailyPvpHandler", "dailyPvpHandler")

    self.trigramsHandler = self:_createHandler("app.network.handler.TrigramsHandler", "TrigramsHandler")

    self.crossPVPHandler = self:_createHandler("app.network.handler.CrossPVPHandler", "crossPVPHandler")
    self.specialActivityHandler = self:_createHandler("app.network.handler.SpecialActivityHandler", "specialActivityHandler")

    self.expansionDungeonHandler = self:_createHandler("app.network.handler.ExpansionDungeonHandler", "expansionDungeonHandler")

    self.changeNameHandler = self:_createHandler("app.network.handler.ChangeNameHandler", "ChangeNameHandler")
    self.rCardHandler = self:_createHandler("app.network.handler.RCardHandler", "RCardHandler")
    self.heroSoulHandler = self:_createHandler("app.network.handler.HeroSoulHandler", "heroSoulHandler")]]
end


function HandlersManager:unInitHandlers( ... )
    for k,handler in pairs(self._handlers) do
        handler:unInitHandler( ... )
    end
end

function HandlersManager:clearHandlers( ... )
    if uf_handlerDispatcher then 
        uf_handlerDispatcher:clearMsg()
    end

    for k,handler in pairs(self._handlers) do
        self[k] = nil 
    end
    self._handlers = {}
end

-- function HandlersManager:reCreateHandlers( ... )
--     self:unInitHandlers()
--     self:clearHandlers()
--     self:_initHandlers()
-- end


return HandlersManager