local EventManager = class("EventManager",cc.Registry.classes_["components.behavior.EventProtocol"])

--[[function EventManager:addEventListener(eventName, listener, tag)
	print("addEventListener--------------------------")
	print(G_Event.EVENT_LOGIN_PLATFORM == nil)
	--local eventNameStr = GlobalFunc.sz_T2S(G_Event.EVENT_LOGIN_PLATFORM)
	self:addEventListener(G_Event.EVENT_LOGIN_PLATFORM, listener, tag)
end]]

return EventManager