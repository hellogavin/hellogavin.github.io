--商店类型
--积分商城
SHOP_TYPE_SCORE = 2

--神秘商店
SHOP_TYPE_SECRET_SHOP = 3

--觉醒商店
SHOP_TYPE_AWAKEN_SHOP = 4

--战宠商店
SHOP_TYPE_PET_SHOP = 7

-- 限时优惠
SHOP_TYPE_TIME_PRIVILEGE = 5

SCORE_TYPE = {
	JING_JI_CHANG = 1,  --竞技场
	MO_SHEN = 2,		--魔神
	DUO_BAO = 3,		--夺宝
	CHUANG_GUAN = 4,	--闯关
	VIP = 5,	--VIP
	JUN_TUAN = 6,       --军团
	ZHUAN_PAN = 7,   --转盘
	CROSS_WAR = 8,		--跨服演武
	INVITOR = 9,		--拉新
	TRIGRAMS = 10,		--八卦
	DAILY_PVP = 11,		--
	HERO_SOUL = 12,		--将灵
}