local PlotlineDungeonType = {
	EASY = 1,	-- 主线副本普通模式
	HARD = 2,   -- 主线副本精英模式
}

return PlotlineDungeonType