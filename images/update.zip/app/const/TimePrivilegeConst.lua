local TimePrivilegeConst = 
{
    CLAIM_STATE = {
        CAN_CLAIM = 1,  -- 可领取
        UNFINISH = 2,   -- 未完成
        CLAIMED = 3,    -- 已领取
	},
}

return TimePrivilegeConst