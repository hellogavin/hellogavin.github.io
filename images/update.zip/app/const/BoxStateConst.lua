local BoxStateConst = {
	CLOSE = 1,  -- 关闭
	OPEN = 2, -- 开启
	CLAIMED = 3, -- 已收取
}

return BoxStateConst