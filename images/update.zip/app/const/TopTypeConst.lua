local TopTypeConst = 
{
    TYPE_FIGHT = 1,             --战力
    TYPE_LV = 2,                --等级
}

return TopTypeConst