local BOXTYPE = 
{
    COPPERBOX = 1,  -- 铜宝箱
    SIVLERBOX = 2,  -- 银宝箱
    GOLDBOX   = 3,  -- 金宝箱
    DUNGEONGATEBOX   = 4,  -- 关卡宝箱
    STORYGATEBOX     = 5, -- 武将传关卡宝箱
}

return BOXTYPE

