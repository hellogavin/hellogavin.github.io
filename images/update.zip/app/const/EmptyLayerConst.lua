--EmptyLayerConst.lua


local EmptyLayerConst = {
	KNIGHTSP = 1,
	EQUIPMENT = 2,
	EQUIPMENTSP = 3,
	TREASURE = 4,
    AWAKENITEM = 5,
    PET = 6,
    PET_FRAGMENT = 7,
    SELECT_PET = 8, -- 选择上阵的战宠
    HERO_SOUL = 9, 
}

return EmptyLayerConst
