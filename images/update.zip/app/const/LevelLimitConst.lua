--等级限制
--在function_level_info表里的id ，不是funciotn_id
local LevelLimitConst = {
		JU_QING_FU_BEN = 1,  	--剧情副本
		JING_JI_CHANG = 2,		--竞技场
		DUO_BAO = 3,			--夺宝
		CHUANG_GUAN = 4,		--闯关
                SAODANG = 9,                    -- 扫荡
                
}

return LevelLimitConst