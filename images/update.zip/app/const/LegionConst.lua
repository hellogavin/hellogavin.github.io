local LegionConst = {
	LearnType = {
		LEARN = 1 ,
		DEVELOP = 2 ,
	}
}

return LegionConst