--GlobalConst.lua

local GlobalConst = {
	USER_NAME_LENGTH_MAX = 18,

	CHAT_MSG_LENGTH_MAX	= 120,

	CAI_WEN_JI_ID = 40040,   --提示用蔡文姬的id
	CAI_WEN_JI_HE_XIE_ID = 20441, --和谐版
}

return GlobalConst
