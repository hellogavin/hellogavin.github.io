local PetBagConst = {
	
	TabType = {
		PET      = 1,	--战宠
		FRAGMENT = 2,   --战宠碎片
		BOOK     = 3,   --图鉴
	},

	DevelopType = {
		STRENGTH = 1,	--升级
		STAR     = 2,	--升星
		REFINE   = 3,   --神炼
	},

}

return PetBagConst