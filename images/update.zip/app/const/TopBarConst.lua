local TopBarConst = 
{	
    TOPBAR_MAIN = 1,            --主页面形式
    TOPBAR_SHOP = 2,            -- 商城形式    
    TOPBAR_TOWER = 3,           -- 闯关形式
    TOPBAR_DUNGEON = 4,         -- 副本形式
    TOPBAR_BAG = 5,             -- 包裹形式
    TOPBAR_STORYDUNGEON = 6 ,   -- 剧情副本形式
    TOPBAR_STRENGTHEN = 7,      --强化形式
    TOPBAR_FRIEND = 8,          --好友
    TOPBAR_TREASURE_ROB = 9,          --夺宝
    TOPBAR_DUNGEON_KONG = 10,   -- 镂空副本形式
    TOPBAR_LEGION = 11,         --军团科技
    TOPBAR_EX_DUNGEON = 12,     -- 过关斩将
}


return TopBarConst

