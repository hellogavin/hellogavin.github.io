TYPE_VIT = 1           -- 体力
TYPE_SPIRIT  = 2       -- 精力
TYPE_CHUZHENG = 3      -- 出征令    

