local DailyPvpConst = {
	NOTEAM = 0,
	MATCHING_TEAM = 1,
	INTEAM = 2,
	MATCHING_FIGHT = 3,
}

return DailyPvpConst

