local ShopVipConst = {
    	TI_LI_DAN = 1,    --体力丹
        JING_LI_DAN = 2,    --精力丹
    	JIN_LONG_BAO_BAO = 3,
    	YIN_LIANG_YI_WAN = 4,
        CHENG_SE_ZHUANG_BEI_XIANG_ZI = 5,
        CHENG_SE_BAO_WU_XIANG_ZI = 6,
        MIAN_ZHAN_PAI_DA = 7,
        MIAN_ZHAN_PAI_XIAO = 8,
        HE_TIAN_YU = 9,
        VIP0_LI_BAO = 10,
        VIP1_LI_BAO = 11,
        VIP2_LI_BAO = 12,
        VIP3_LI_BAO = 13,
        VIP4_LI_BAO = 14,
        VIP5_LI_BAO = 15,
        VIP6_LI_BAO = 16,
        VIP7_LI_BAO = 17,
        VIP8_LI_BAO = 18,
        VIP9_LI_BAO = 19,
        VIP10_LI_BAO = 20,
        VIP11_LI_BAO = 21,
        VIP12_LI_BAO = 22,
        CHU_ZHENG_LING = 23,
}



return ShopVipConst