-- HandBookConst.lua

local HandBookConst = {
	
	HandType = {
		KNIGHT = 0,	--武将
		PET    = 1,	--战宠
	},

}

return HandBookConst