local ThemeDropConst = {
	
	AstrologyType = {
		FREE = 0,
		ONCE = 1,
		TEN = 2,
	},

	TOTAL_SCHEDULE = 1000,
}

return ThemeDropConst