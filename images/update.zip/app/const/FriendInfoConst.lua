--FriendInfoConst.lua


local FriendInfoConst = {
	ADDFRIEND = 1,
	ADDBLACK = 2,
	CHAT = 3,
	MAIL = 4,
	FORM = 5,
	FIGHT = 6,
}

return FriendInfoConst
