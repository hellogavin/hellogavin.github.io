local ExpansionDungeonConst = {}

ExpansionDungeonConst.PASS_TYPE = {
	MAX_FIGHT_VALUE = 1,  -- 最强战力
	MIN_FIGHT_VALUE = 2,  -- 极限战力
}

return ExpansionDungeonConst