
local TurnplateLayer = class("TurnplateLayer", SMCCSNormalLayer)


function TurnplateLayer:init(size, angles, startIndex)
    self._angles = angles
    self._startIndex = startIndex
    self._showList = {}
    self:setContentSize(CCSize(size.width,size.height))
    
    self.isMove = false

    -- 圆心
    self.m_nCenter = ccp(size.width*0.5,size.height*0.5)
 
    -- 椭圆长轴
    self.m_longAxis = size.width*0.45
    
    -- 椭圆短轴
    self.m_shortAxis = self.m_longAxis*0.85
    

    --zorder起点
    self.m_ZStart = 0
    
    -- 最小Y轴
    self.YMin =  self.m_nCenter.y - self.m_shortAxis
    
    -- 最大Y轴
    self.YMax = self.m_nCenter.y + self.m_shortAxis
    
    self:registerTouchEvent(false,true,0)
    
    self._knightsLayer = display.newNode()

    self:addChild(self._knightsLayer)

    
    -- for touch
    self.m_nTouchBegin = ccp(0,0)
    self.m_nTouchMove = false 
    
end

-- @desc 检查是否回滚回去
function TurnplateLayer:judgeNeedMoveBack(dir, step)
    --print("judgeNeedMoveBack " .. dir .. "," ..  step .. "," .. tostring(self.isMove)  )
    if self.isMove == true then
        return 
    end
    self.isMove = true
    -- 计算下一个位置的角速度

    for k,v in pairs(self._showList) do
        v.speed,v.pos,v.EndAngle = self:_calcAngleSpeed(v,v.pos,dir, step)
        v.StartAngle = v.angle
    end
    
    self._timer = G_GlobalFunc.addTimer(0.05,handler(self,self._moveBackAnimation))
end

-- function TurnplateLayer.create(size)
--     local _layer = TurnplateLayer.new()
--     _layer:init(size)
--     return _layer
-- end


function TurnplateLayer:addNode(node, pos)
    print("addnode", node, pos)
    node.pos = pos
    node.angle = self:_calcStartAndEndAngle(pos, 1)
    node.EndAngle = node.angle
 
    self._knightsLayer:addChild(node)
    
    if pos == 0 then 
        node:setPosition(ccp(300 , 170))
    end
    
    if pos ~= 0 then 
        table.insert(self._showList,node)
    end

    self:_arrange()
end

function TurnplateLayer:_refresh()
    
    for k,v in pairs(self._showList) do 
        v.angle = self:_calcStartAndEndAngle(v.pos, 1) 
    end

    self:_arrange()
end

function TurnplateLayer:getOrderList()
    local _list = self:_orderByY()
    return _list
end




--根据节点当前角度angle计算位置, 缩放, zorder
function TurnplateLayer:_arrange()
    --self:arrangeAngle()
    self:_arrangePosition()
    self:_arrangeScale()
    self:_arrangeZOrder()
end

function TurnplateLayer:onLayerExit()
    self:_removeTimer()
end


-- @desc 设置位置
function TurnplateLayer:_arrangePosition()
    for k,v in pairs(self._showList) do
        local fAngle = math.fmod(v.angle, 360.0)
        local x = math.cos(fAngle/180.0*3.14159)*self.m_longAxis + self.m_nCenter.x
        local y = math.sin(fAngle/180.0*3.14159)*self.m_shortAxis*0.5 + self.m_nCenter.y
        -- if G_Me.formationData:getMainKnightId() == v._knightId then
        --    v:setPosition(ccp(300 , 170))
        -- else
            v:setPosition(ccp(x, y))
        -- end
    end
end

-- @desc 重新设置z轴
function TurnplateLayer:_arrangeZOrder()
    local ZMax = self.m_ZStart + #self._showList

    local _list = self:_orderByY()

    for k,v in pairs(_list) do
        v:setZOrder(ZMax)
        ZMax = ZMax + 1
    end
end

function TurnplateLayer:setCenterNode(panel)
     self._mainKnightPanel = panel
end

function TurnplateLayer:_orderByY()
    local _list = {}
    for k,v in pairs(self._showList) do
        table.insert(_list,v)
    end
     
    if (self._mainKnightPanel ~= nil) then
        table.insert(_list, self._mainKnightPanel)
    end
    
    table.sort(_list,function(p1,p2) 
        return p1:getPositionY() > p2:getPositionY()
    end)
    return _list
end

function TurnplateLayer:_arrangeScale ()
     for k,v in pairs(self._showList) do
        local fy = v:getPositionY() 
        if fy < 0 then fy = 0 end
            if G_Me.formationData:getMainSpriteId() == v._knightId then
               v:setImageScale(0.9)
          else
               local fScale = fy /(self.m_shortAxis*1.5)
               v:setImageScale(1- 1*fScale)
          end
    end
end

--当自动滑动的过程中,根据速度修改卡牌的角度, 当卡牌到达目标角度时,返回,停止
function TurnplateLayer:_moveShow()
    local finished = true
    for k,v in pairs(self._showList) do  
        if v.speed ~= 0 then
            --print( k .. " " .. math.abs(v.angle - v.EndAngle) .. " ---" .. math.abs(v.speed))
            local dstAngle =  v.EndAngle
            local dir = v.speed > 0 and 1 or -1
            if dir*(dstAngle - v.StartAngle)< 0 then
                dstAngle = dstAngle + 360*dir
            end
            if math.abs(v.angle - dstAngle) <= math.abs(v.speed)
              or  (v.speed <0 and v.angle <= dstAngle ) 
              or (v.speed >0 and v.angle >= dstAngle ) then 
                v.angle = v.EndAngle
                v.speed = 0
            else
                v.angle = v.angle+v.speed
                finished = false
            end
        end
    end
    return finished
end

-- @desc 计算角速度
--自动滑动的时候, 需要知道现在要往哪个方向(dir)滑动多少格(step), 然后计算出一个速度, 然后在movieShow里修改angle
function TurnplateLayer:_calcAngleSpeed(sprite,pos,dir, step)
    if step == nil then
        step = 1  --滑多少格
    end
    local temp = pos + dir*step
    local len = #self._angles
    if temp > len then 
        temp = temp - len 
    end
    
    if temp  < 1 then 
        temp = temp + len 
    end
    local _startAngle,_endAngle = self:_calcStartAndEndAngle(pos,dir, step)
    --sprite.angle = _startAngle
    
    local subValue = _endAngle - sprite.angle
    if dir*subValue< 0 then
        subValue = subValue + 360*dir
    end
    
    return subValue/3,temp,_endAngle
end

-- @desc 计算下一个位置的角度
-- @return param1 开始角度 @param2终点角度
function TurnplateLayer:_calcStartAndEndAngle(index,dir,step)
    if step == nil then
        step = 1
    end


    local startIndex = self._startIndex + index 
    if startIndex > #self._angles then
        startIndex = startIndex - #self._angles
    end


    local endIndex = startIndex + dir*step 
    if endIndex > #self._angles then
        endIndex = endIndex -  #self._angles
    end
    if endIndex < 1 then
        endIndex = endIndex +  #self._angles
    end


    local startAngle = self._angles[startIndex]
    local endAngle  = self._angles[endIndex]

    if dir == 1 then
        if startAngle > endAngle then
            if startAngle - 360 < 0 then
                endAngle = endAngle + 360
            else
                startAngle = startAngle - 360
            end
        end
    else
        if startAngle < endAngle then
            if endAngle - 360 < 0 then
                startAngle = startAngle + 360
            else
                endAngle = endAngle - 360
            end
        end
    end

    return startAngle, endAngle
end

-- @desc 点击武将
function TurnplateLayer:onClick(pt)
   local _list = self:_orderByY()
   
   for k,v in pairs(_list) do
        if v:containsPt(pt) then
     
            if self:onClickNode(v) then
                return
            end


        end

   end
   
   return nil 
end

function TurnplateLayer:_removeTimer()
    if self._timer then
        G_GlobalFunc.removeTimer(self._timer)
        self._timer = nil
    end
end

function TurnplateLayer:onTouchBegin(x,y)
    if self.isMove  then
        return
    end
    self.m_nTouchBegin = self:getParent():convertToNodeSpace(ccp(x,y))    
    local b =  G_WP8.CCRectContainPt(CCRect(self:boundingBox().origin.x, self:boundingBox().origin.y, self:boundingBox().size.width, self:boundingBox().size.height + 500), self.m_nTouchBegin)

    return b
end



function TurnplateLayer:onTouchMove(x,y)
    if self.isMove  then
        return
    end    
    local pt = self:getParent():convertToNodeSpace(ccp(x,y)) 
    local deltaX = pt.x - self.m_nTouchBegin.x
    print("deltaX", deltaX)
    for k,v in pairs(self._showList) do
        local  startAngle, endAngle = self:_calcStartAndEndAngle(v.pos, deltaX > 0 and 1 or -1, 1)
        local percent = math.abs(deltaX/300)
        if percent > 1 then percent = 1 end  

        v.angle = startAngle + (endAngle - startAngle)*percent

    end

    self:_arrange()
    self:onMove()


end

function TurnplateLayer:onTouchCancel(x,y)
    self:onTouchEnd(x, y)
end


function TurnplateLayer:onTouchEnd(x,y)

        local pt = self:getParent():convertToNodeSpace(ccp(x,y))

        --self:judgeNeedMoveBack()
        local fDist = math.abs(pt.x - self.m_nTouchBegin.x)
        --print("fdist=" .. fDist)
        if fDist > 10 then   
            local step = 1
            local dir = (pt.x - self.m_nTouchBegin.x)/math.abs(pt.x - self.m_nTouchBegin.x)
            self:judgeNeedMoveBack(dir, step)
            return
        else
            --这个时候可能位置有点移动, 修正一下
            self:_refresh()

            self:onMoveStop("refresh")
            self:onClick(ccp(x,y))
        
        end

end

function TurnplateLayer:onMoveStop(reason)
    
end

function TurnplateLayer:_moveBackAnimation()
    local key = table.keys(self._showList)
    if self:_moveShow() then
        self:_removeTimer()
        self.isMove = false
        --print("end animation")
        G_SoundManager:playSound(require("app.const.SoundConst").GameSound.UI_SLIDER)

        self:onMoveStop("back")
    end
    self:_arrange()
end



return TurnplateLayer
