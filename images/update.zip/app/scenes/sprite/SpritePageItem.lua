--SpritePageItem.lua


local SpritePageItem = class ("SpritePageItem", function (  )
	return CCSPageCellBase:create("ui_layout/knight_pageItem.json")
end)

function SpritePageItem:initPageItem( index , parentLayer, teamId )
		local formationIndex, knightId = G_Me.formationData:getFormationIdSpriteIdByOrderIndex(teamId, teamId == 2 and (index - 6) or index)
print("--------------------------------------knightId")
print(knightId)
		self._knightId = knightId
		self._posIndex = index
		self._parentLayer = parentLayer
		self._teamId = teamId

		local panel = self:getWidgetByName("Panel_hero")
    	if panel then
    		panel:removeAllChildren()
    	end

		local baseId = G_Me.bagData.spritesData:getBaseIdBySpriteId(knightId)
		print(baseId)
		local resId = 0
		local knightInfo = nil
		if baseId > 0 then
			knightInfo = sprite_info.get(baseId)
		end
		--print("knightInfo:" .. GlobalFunc.sz_T2S(knightInfo))
		if knightInfo ~= nil then
			resId = knightInfo["res_id"]
		end
		print("resId:" .. resId)
		if knightId == G_Me.formationData:getMainSpriteId() then 
        	resId = G_Me.dressData:getDressedPic()
    	end
		print("resId:" .. resId)
		self:showWidgetByName("ImageView_hero", resId <= 0 and index <= 6)

    	if panel and resId > 0 then
    		local size = panel:getSize()
    		local spritePic = require("app.scenes.common.SpritePic")
			local pic = spritePic.createSpritePic(resId, panel, nil, true)
			panel:setScale(1)
            -- --侠客呼吸动作
            local EffectSingleMoving = require "app.utility.effect.EffectSingleMoving"
            EffectSingleMoving.run(panel, "smoving_idle", nil, {}, 1+ math.floor(math.random()*30))
            
		else
			__Log("panel is nil or resId <= 0")
    	end
end

function SpritePageItem:_onHeroPageIndexClicked( posIndex, knightId )
	local heroDesc = require("app.scenes.sprite.SpriteDescLayer")
	heroDesc.showSpriteDesc(sm_sceneManager:getCurScene(), self._teamId, knightId, posIndex)
end

return SpritePageItem