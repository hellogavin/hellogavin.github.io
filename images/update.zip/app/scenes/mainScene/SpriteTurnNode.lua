local _SpritePic = require("app.scenes.common.SpritePic")
local TurnNode = require("app.scenes.common.turnplate.TurnNode")
local SpriteTurnNode = class("SpriteTurnNode", TurnNode)

import("title_info")
function SpriteTurnNode.create(...)
    return SpriteTurnNode.new("ui_layout/mainscene_Pedestal.json", ...)
end

function SpriteTurnNode:ctor(...)
    self.super.ctor(self,...)
    self._resId = 0
    self._slotTag = 0 -- 阵容位
    self._image = nil
end

function SpriteTurnNode:getResid()
    return self._resId
end

function SpriteTurnNode:setData(SpriteId, baseId, slotIndex)

    self._slotTag = slotIndex
    self._baseId = baseId
    self._SpriteId = SpriteId

    local name = ""
    local quality = 0
    local resId = 0 
    local SpriteInfo = sprite_info.get(baseId)
    if SpriteInfo then
        quality = SpriteInfo.quality
        resId = SpriteInfo.res_id
        name = SpriteInfo.name

    end
    --self:getImageViewByName("ImageView_Pedestal"):setVisible(false)
    local effectEnable = require("app.scenes.mainscene.SettingLayer").showEffectEnable()
    local _pedestal = self:getImageViewByName("ImageView_Pedestal")
    _pedestal:setVisible(not effectEnable)
    if resId == 0  then 
        -- _pedestal = tolua.cast(_pedestal,"ImageView")
        -- _pedestal:setTag(index)
        
        -- 显示是否可以上阵
        
        local levelArr = G_Me.userData:getTeamSlotOpenLevel()
        if G_Me.userData.level >= levelArr[self._slotTag] then
            local imgJia = self:getImageViewByName("ImageView_Jia")
            imgJia:setVisible(not effectEnable)
            local panel = self:getPanelByName("Panel_Light")
            if panel and effectEnable then
                 local secretShine = require("app.utility.effect.EffectNode").new("effect_szts")
                 local size = _pedestal:getContentSize()
                panel:addNode(secretShine, 10)
                secretShine:setPosition(ccp(size.width/2,size.height/2))
                secretShine:play()
            end
        else
            _pedestal:loadTexture(G_Path.MainPage.PEDESTAL_LOCK)
            _pedestal:setVisible(true)
        end
        return
    end

    local _SpriteNode = self:getPanelByName("Panel_Knight")
    _SpriteNode:setVisible(true)

    -- 称号背景图片
    local titleBg = nil

    if SpriteId == G_Me.formationData:getMainSpriteId() then 
        resId = G_Me.dressData:getDressedPic()

        -- 主角头顶添加称号
        if G_Me.userData:getTitleId() > 0 then
            local titleInfo = title_info.get(G_Me.userData.title_id)
            titleBg = ImageView:create()
            titleBg:loadTexture(titleInfo.picture, UI_TEX_TYPE_LOCAL)
            titleBg:setPosition(ccp(-20, 380))

            local titleLabel = Label:create()
            titleLabel:setFontName("ui/font/FZYiHei-M20S.ttf")
            titleLabel:setFontSize(32)
            titleLabel:setText(titleInfo.name)
            titleLabel:setColor(Colors.getColor(titleInfo.quality))
            titleLabel:createStroke(Colors.strokeBrown, 3)
            titleLabel:setPosition(ccp(0, 0))

            titleBg:addChild(titleLabel) 
            titleBg:setScale(1.3) 
        elseif G_Me.bagData:isTitleOutOfDate(G_Me.userData.title_id) then
            -- 称号过期，刷新战力
            G_HandlersManager.titleHandler:sendUpdateFightValue()
        end
    end
    self._image = _SpritePic.createSpriteNode(resId, "sprite_" .. self._slotTag, true)
    --pSprite:setTag(index)
    self._image:setScale(0.8)
    _SpriteNode:addNode(self._image)
    -- 在这里添加使称号不被人物遮挡
    if titleBg then        
        -- 加特效
        local starEffect = require("app.utility.effect.EffectNode").new("effect_chenhao_star")
        titleBg:addNode(starEffect)
        starEffect:setScale(1.5)
        starEffect:play()
        
        self._image:addChild(titleBg)
    end

    -- --侠客呼吸动作
    local EffectSingleMoving = require "app.utility.effect.EffectSingleMoving"
    EffectSingleMoving.run(self._image, "smoving_idle", nil, {}, 1+ math.floor(math.random()*30))
 
    --    将名字转换成单个字符
    local _listChar = self:convertSpriteName(name)

    local Panel_Name = self:getPanelByName("Panel_Name")
    local _height = 0
    local _panelHeight = Panel_Name:getContentSize().height
    -- 设置名字
    for i=1,6 do
        local _nameLabel = self:getLabelByName("Label_Name" .. i)
        -- _nameLabel = tolua.cast(_nameLabel,"Label")
        if _nameLabel and _listChar[i] then
            -- 这里-6使字间距变小了
            _nameLabel:setPositionY(_panelHeight - _height - 6)
            if quality ~= nil then
                _nameLabel:setColor(Colors.qualityColors[quality])
            end
            _nameLabel:setText(_listChar[i])
            -- 这里-6使字间距变小了
            _height = _height + _nameLabel:getContentSize().height - 6
            --_nameLabel:createStroke(Colors.strokeBrown,1)
        end
    end

    local lenth = #_listChar> 6 and 6 or #_listChar
    local y = -((6-lenth)/6*_panelHeight)/2 -_panelHeight/2
    Panel_Name:setPositionY(y) 
end
 
-- 更改主角名
function SpriteTurnNode:changeName(  )
    local SpriteInfo = sprite_info.get(self._baseId)
    local quality = 0
    local name = ""
    if SpriteInfo then
        quality = SpriteInfo.quality
        name = SpriteInfo.name
    end

    for i=1,6 do
        local nameLabel = self:getLabelByName("Label_Name" .. i)
        nameLabel = tolua.cast(nameLabel,"Label")
        if nameLabel then
            nameLabel:setText("") 
        end
    end

    --    将名字转换成单个字符
    local listChar = self:convertSpriteName(name)

    local panelName = self:getPanelByName("Panel_Name")
    local height = 0
    local panelHeight = panelName:getContentSize().height
    -- 设置名字
    for i=1,6 do
        local nameLabel = self:getLabelByName("Label_Name" .. i)
        nameLabel = tolua.cast(nameLabel,"Label")
        if nameLabel and listChar[i] then
            -- 这里-6使字间距变小了
            nameLabel:setPositionY(panelHeight - height - 6)
            if quality ~= nil then
                nameLabel:setColor(Colors.qualityColors[quality])
            end
            nameLabel:setText(listChar[i])
            -- 这里-6使字间距变小了
            height = height + nameLabel:getContentSize().height - 6
        end
    end

    local lenth = #listChar> 6 and 6 or #listChar
    local y = -((6-lenth)/6*panelHeight)/2 -panelHeight/2
    panelName:setPositionY(y)
end


-- @字符串转换
function SpriteTurnNode:convertSpriteName(strName)
   
    local name_t = {}
    for uchar in string.gfind(strName, "[%z\1-\127\194-\244][\128-\191]*") do 
        name_t[#name_t+1] = uchar 
        if #name_t >= 6 then
            break
         end
    end
    return name_t
end

function SpriteTurnNode:setImageScale(s)
    self:getRootWidget():setScale(s)
end

function SpriteTurnNode:hasSprite()
    return self._SpriteId ~= 0
end

function SpriteTurnNode:getSlotTag()
    return self._slotTag
end

function SpriteTurnNode:getSomethingToSay()
    local SpriteInfo = sprite_info.get(self._baseId)
    if SpriteInfo then
        return SpriteInfo.statement
    else
        return ""
    end
end

function SpriteTurnNode:playSpriteCommonAudio( ... )
    local SpriteInfo = sprite_info.get(self._baseId)
    if SpriteInfo and type(SpriteInfo.common_sound) == "string" and #SpriteInfo.common_sound > 3 then 
        G_SoundManager:playSound(SpriteInfo.common_sound)
    end
end

function SpriteTurnNode:stopSpriteCommonAudio( ... )
    local SpriteInfo = sprite_info.get(self._baseId)
    if SpriteInfo and type(SpriteInfo.common_sound) == "string" and #SpriteInfo.common_sound > 3 then 
        G_SoundManager:stopSound(SpriteInfo.common_sound)
    end
end

--pt是个世界坐标, 判断Pt是否落在SpriteTurnNode 上
function SpriteTurnNode:containsPt(pt)
    local image 
    if self:hasSprite() then
        image = self._image.imageNode 
    else
        image = self:getPanelByName("Panel_Light")
    end
 
    if image == nil then
        return false
    end
 
    local imagePt = image:convertToNodeSpace(  pt  )
    --print("ptx=" .. imagePt.x .. ",pty=" .. imagePt.y)
    local size = image:getContentSize()
    local w = size.width*image:getScaleX()
    local h = size.height*image:getScaleY()

    local rect = CCRectMake(-w/2, -h/2, w, h)
    if not self:hasSprite() then
        rect = CCRectMake(0, 0, w, h)
    end
    --return rect:containsPoint(imagePt)
    return G_WP8.CCRectContainPt(rect, imagePt)
end


return SpriteTurnNode
