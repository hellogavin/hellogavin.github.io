local _spritePic = require("app.scenes.common.SpritePic")
local TurnplateLayer = require("app.scenes.common.turnplate.TurnplateLayer")
local SpriteTurnNode = require("app.scenes.mainscene.SpriteTurnNode")

local SpriteTurnplateLayer = class("SpriteTurnplateLayer", TurnplateLayer)
 
local EffectSingleMoving = require "app.utility.effect.EffectSingleMoving"
 
--6个侠客的角度

-- local angles = {55, 90, 125, 200, 270, 340}
--local angles = {55, 90, 125, 200, 270, 340}
local angles = {340, 55, 125, 200, 270}

function SpriteTurnplateLayer:init(size, playVoice)
    self._lastTurnPlate = nil
    self._mainSpritePanel = nil
    self.super.init(self,size, angles, 4)
 
    self._wordsLayer = display.newNode()

    self:addChild(self._wordsLayer)

    for i=1,6 do
         local spriteId, baseId = G_Me.formationData:getTeamSpriteIdAndBaseIdByIndex(1, i)
         
         local _panel = SpriteTurnNode.create()
         _panel:setData(spriteId, baseId, i)

         -- 将主角的panel保存下来
         if i == 1 then
            self:setCenterNode(_panel) 
         end

         --不同的阵容位对应于圆盘的不同pos
         _pos = i - 1
         --[[
         local _pos = 0
         if i == 1 then
             _pos = 1
         elseif i == 3 then
            _pos = 2
         elseif i == 2 then
              _pos = 6
         elseif i == 4 then
             _pos = 3
         elseif i == 5 then
            _pos = 5
         else
            _pos = 4
         end
         ]]
           
            print("eeeeeeeeeeeeeeeeee")
            self:addNode(_panel, _pos) 
             
         if playVoice and _pos == 1 then 
            --print("eeeeeeeeeeeeeeeeee",_pos)
            self:saySomething()
            _panel:playSpriteCommonAudio()
         end
    end
end

function SpriteTurnplateLayer:onLayerEnter(  )
    sm_eventManager:addEventListener(G_EventMsg.EVENT_CHANGE_ROLE_NAME_SUCCEED, self._onChangeRoleNameSucceed, self)
end

function SpriteTurnplateLayer:_onChangeRoleNameSucceed()
    if self._mainSpritePanel then
        self._mainSpritePanel:changeName()
    end
end


function SpriteTurnplateLayer:onLayerExit() 
    self.super.onLayerExit(self)
end
 
function SpriteTurnplateLayer:onMove()
    self:_clearSaySomething()
end

function SpriteTurnplateLayer:onMoveStop(reason)
    if reason == "back" then
        self:saySomething()
    end 
end
 
-- @desc 点击武将
function SpriteTurnplateLayer:onClick(pt)
   local _list = self:getOrderList()
   local clickNode = nil
   
   for k,v in pairs(_list) do 
       print("onClick:", k, v.pos, v._spriteId)
       
        if v:containsPt(pt) then
            local _angle = v.angle
            if _angle < 0 then _angle = _angle + 360 end
            if _angle > 360 then _angle = _angle - 360 end

            if _angle == 270 or _angle == 340 or _angle == 200 then
                clickNode = v
            else
                --旋转到整中间, 找到需要往哪个方向转, 转几步, 中间那个方向在angles数组里是固定第5个
                --local angles = {55, 90, 125, 200, 270, 340}

                -- local dir 
                -- local step 
                -- for i,v in ipairs(angles) do 
                --     if 
                -- end
                if _angle == 55 then
                    self:judgeNeedMoveBack(-1, 2)
                elseif  _angle == 90 then
                    self:judgeNeedMoveBack(1, 3)
                elseif  _angle == 125 then
                    self:judgeNeedMoveBack(1, 2)
                elseif  _angle == 200 then
                    self:judgeNeedMoveBack(1, 1)
                elseif  _angle == 340 then
                    self:judgeNeedMoveBack(-1, 1)
                end 
            end
        end 
   end
  
   --正中间3个位置
   -- print( " clicknode " .. tostring(clickNode)  )

   if clickNode   then  
        if not clickNode:hasSprite() then
            local levelArr = G_Me.userData:getTeamSlotOpenLevel()
            if G_Me.userData.level < levelArr[clickNode:getSlotTag()] then -- 检查槽位是否开启
                G_MovingTip:showMovingTip(G_lang:get("LANG_MAINPAGE_OPENLEVEL",{level=levelArr[clickNode:getSlotTag()]}))
                return
            end 
        end 
        
        G_commonLayerModel:getSpeedbarLayer():setSelectBtn("Button_LineUp")
        sm_sceneManager:replaceScene(require("app.scenes.sprite.SpriteScene").new(clickNode:getSlotTag()))  
   end
end
 
function SpriteTurnplateLayer:_clearSaySomething()
    -- if self._sayEffect ~= nil then
    --     self._sayEffect:stop()
    --     self._sayEffect = nil
    --     self._spriteSayLayer:setVisible(false)
    -- end
    if self._spriteSayLayer then
        self._spriteSayLayer:getImageViewByName('Image_desc'):setVisible(false)
        self._spriteSayLayer:getImageViewByName('Image_desc'):stopAllActions()
    end
end
function SpriteTurnplateLayer:saySomething()
    if self._spriteSayLayer == nil then
        self._spriteSayLayer  = SMCCSNormalLayer.new("ui_layout/mainscene_knightSayLayer.json")
        self._spriteSayLayer:setPosition(ccp(350,255))     
        self._spriteSayLayer:setVisible(false)

        self._wordsLayer:addChild(self._spriteSayLayer)
    end

    self:_clearSaySomething()

    if self._lastTurnPlate then 
        self._lastTurnPlate:stopSpriteCommonAudio()
        self._lastTurnPlate = nil
    end

    --取到最前面那个侠客
    local _list = self:getOrderList()
    for k,v in pairs(_list) do 
    print("saySomething", k, v.pos)
        if v:hasSprite() then
            print("saySomething2", v:getSomethingToSay())
        end
    end

    for k,v in pairs(_list) do 
        if v.pos == 1 then 
            if v:hasSprite() then
                self._lastTurnPlate = v
                local str = v:getSomethingToSay()
                v:playSpriteCommonAudio()
                self._spriteSayLayer:getLabelByName("Label_desc"):setText(str)
                self._spriteSayLayer:getLabelByName("Label_desc"):setFontName("res/ui/font/FZYiHei-M20S.TTF")
                self._spriteSayLayer:setVisible(true)
                self._spriteSayLayer:getImageViewByName('Image_desc'):setScale(1)
                -- self._sayEffect = EffectSingleMoving.run(self._spriteSayLayer:getImageViewByName('Image_desc'), "smoving_say", function(event) 
                --     self:_clearSaySomething()
                
                -- end, {position=true})
                GlobalFunc.sayAction(self._spriteSayLayer:getImageViewByName('Image_desc'),true)
            end
            
            break
        end
    end

end

return SpriteTurnplateLayer
